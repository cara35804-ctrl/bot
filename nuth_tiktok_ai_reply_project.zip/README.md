# NUTH TikTok AI Auto Reply

Python/FastAPI project for an AI reply backend that can receive approved TikTok webhook events, keep conversation memory in SQLite, generate replies with OpenAI, and forward replies to an approved outbound endpoint.

## Important TikTok API note

TikTok's public developer documentation exposes webhooks and several other products, but the exact ability to send direct-message replies depends on the TikTok product/API and permissions approved for your app.

This project therefore does **not** pretend that a universal TikTok DM-send endpoint exists. You must put the real HTTPS outbound endpoint and request contract supplied by the TikTok product you have access to into `TIKTOK_REPLY_URL`, or adapt `send_tiktok_reply()` to that approved API.

TikTok webhook endpoints must use HTTPS and should return HTTP 200 quickly. TikTok can retry webhook delivery, so this project stores event IDs to make processing idempotent.

## 1. Install

Python 3.11+ is recommended.

```bash
python -m venv .venv
```

Windows:

```bash
.venv\Scripts\activate
```

Linux/macOS:

```bash
source .venv/bin/activate
```

Then:

```bash
pip install -r requirements.txt
```

## 2. Environment variables

Copy:

```text
.env.example -> .env
```

Fill in:

```text
OPENAI_API_KEY=...
OPENAI_MODEL=gpt-5
TIKTOK_CLIENT_SECRET=...
TIKTOK_REPLY_URL=...
TIKTOK_REPLY_TOKEN=...
```

Never upload `.env` or your API keys to GitHub.

## 3. Run locally

```bash
python app.py
```

Or:

```bash
uvicorn app:app --reload --port 8000
```

Health check:

```text
GET /health
```

## 4. TikTok webhook

Deploy the app to an HTTPS host such as Railway/Render/VPS with HTTPS.

Register:

```text
https://YOUR-DOMAIN/webhook/tiktok
```

as the webhook callback in your TikTok Developer app.

Set the client secret in:

```text
TIKTOK_CLIENT_SECRET
```

The signature verification follows TikTok's documented `TikTok-Signature` format.

## 5. OpenAI

The application uses the official OpenAI Python SDK and the Responses API.

The SDK reads `OPENAI_API_KEY` from the environment.

## 6. Deploy to Railway

Push the project to GitHub.

Create a Railway project from the repository.

Add the environment variables from `.env.example`.

Railway will use:

```text
uvicorn app:app --host 0.0.0.0 --port $PORT
```

## 7. Deploy to Render

Create a Web Service from the repository.

Render can use the included `render.yaml`, or configure:

Build:

```text
pip install -r requirements.txt
```

Start:

```text
uvicorn app:app --host 0.0.0.0 --port $PORT
```

Add all required environment variables.

## 8. Test without TikTok

You can test the webhook with curl.

Windows PowerShell:

```powershell
$body = '{"event":"test.message","user_openid":"demo-user","content":"Hello, can you help me?"}'
Invoke-RestMethod -Uri "http://127.0.0.1:8000/webhook/tiktok" -Method POST -ContentType "application/json" -Body $body
```

If `TIKTOK_REPLY_URL` is empty, the AI reply will be generated and logged instead of being sent anywhere.

## 9. Admin switch

Enable:

```http
POST /admin/auto-reply?enabled=true
```

Disable:

```http
POST /admin/auto-reply?enabled=false
```

For production, protect this admin endpoint with authentication before exposing it publicly.

## 10. Database

SQLite is stored in:

```text
memory.db
```

It contains:

- conversation messages
- processed webhook event IDs
- application settings

For a multi-instance production deployment, use PostgreSQL instead of SQLite and replace the small database layer.

## Security

- Keep secrets in environment variables.
- Use HTTPS.
- Verify TikTok webhook signatures.
- Do not put API keys in source code.
- Do not commit `.env`.
- Add authentication to `/admin/*` before production use.
