import hashlib
import hmac
import json
import logging
import os
import sqlite3
import time
from contextlib import closing
from typing import Any, Dict, Optional

import httpx
from dotenv import load_dotenv
from fastapi import FastAPI, Header, HTTPException, Request
from openai import OpenAI

load_dotenv()

logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)s | %(message)s")
logger = logging.getLogger("tiktok-ai-reply")

APP_NAME = os.getenv("APP_NAME", "NUTH TikTok AI Reply")
HOST = os.getenv("HOST", "0.0.0.0")
PORT = int(os.getenv("PORT", "8000"))

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "")
OPENAI_MODEL = os.getenv("OPENAI_MODEL", "gpt-5")
AI_SYSTEM_PROMPT = os.getenv(
    "AI_SYSTEM_PROMPT",
    "You are NUTH, a polite and professional TikTok customer-support assistant. "
    "Reply naturally and concisely. Do not claim to be human. "
    "If you do not know something, say so and ask for the needed details."
)

TIKTOK_CLIENT_SECRET = os.getenv("TIKTOK_CLIENT_SECRET", "")
TIKTOK_REPLY_URL = os.getenv("TIKTOK_REPLY_URL", "")
TIKTOK_REPLY_TOKEN = os.getenv("TIKTOK_REPLY_TOKEN", "")

AUTO_REPLY_ENABLED = os.getenv("AUTO_REPLY_ENABLED", "true").lower() == "true"
OWNER_ACTIVE_PAUSE_SECONDS = int(os.getenv("OWNER_ACTIVE_PAUSE_SECONDS", "60"))
SPAM_WINDOW_SECONDS = int(os.getenv("SPAM_WINDOW_SECONDS", "60"))
SPAM_MAX_MESSAGES = int(os.getenv("SPAM_MAX_MESSAGES", "5"))
MAX_HISTORY = int(os.getenv("MAX_HISTORY", "12"))

DB_PATH = os.getenv("DATABASE_PATH", "memory.db")

app = FastAPI(title=APP_NAME, version="1.0.0")
client = OpenAI(api_key=OPENAI_API_KEY) if OPENAI_API_KEY else None


def db():
    return sqlite3.connect(DB_PATH)


def init_db():
    with closing(db()) as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS messages (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                conversation_id TEXT NOT NULL,
                role TEXT NOT NULL,
                content TEXT NOT NULL,
                created_at INTEGER NOT NULL
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS events (
                event_id TEXT PRIMARY KEY,
                created_at INTEGER NOT NULL
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS settings (
                key TEXT PRIMARY KEY,
                value TEXT NOT NULL
            )
        """)
        conn.commit()


@app.on_event("startup")
def startup():
    init_db()
    logger.info("%s started", APP_NAME)


def setting(key: str, default: str) -> str:
    with closing(db()) as conn:
        row = conn.execute("SELECT value FROM settings WHERE key = ?", (key,)).fetchone()
        return row[0] if row else default


def set_setting(key: str, value: str):
    with closing(db()) as conn:
        conn.execute(
            "INSERT INTO settings(key, value) VALUES(?, ?) "
            "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            (key, value),
        )
        conn.commit()


def already_processed(event_id: str) -> bool:
    with closing(db()) as conn:
        row = conn.execute("SELECT 1 FROM events WHERE event_id = ?", (event_id,)).fetchone()
        if row:
            return True
        conn.execute("INSERT INTO events(event_id, created_at) VALUES(?, ?)", (event_id, int(time.time())))
        conn.commit()
        return False


def save_message(conversation_id: str, role: str, content: str):
    with closing(db()) as conn:
        conn.execute(
            "INSERT INTO messages(conversation_id, role, content, created_at) VALUES(?, ?, ?, ?)",
            (conversation_id, role, content, int(time.time())),
        )
        conn.commit()


def history(conversation_id: str):
    with closing(db()) as conn:
        rows = conn.execute(
            "SELECT role, content FROM messages "
            "WHERE conversation_id = ? ORDER BY id DESC LIMIT ?",
            (conversation_id, MAX_HISTORY),
        ).fetchall()
    return list(reversed(rows))


def recent_user_message_count(conversation_id: str) -> int:
    cutoff = int(time.time()) - SPAM_WINDOW_SECONDS
    with closing(db()) as conn:
        row = conn.execute(
            "SELECT COUNT(*) FROM messages "
            "WHERE conversation_id = ? AND role = 'user' AND created_at >= ?",
            (conversation_id, cutoff),
        ).fetchone()
    return int(row[0])


def verify_tiktok_signature(raw_body: bytes, signature: Optional[str]) -> bool:
    # TikTok webhook signature format: t=<timestamp>,s=<hex signature>
    # signed payload = "<timestamp>.<raw JSON body>"
    if not TIKTOK_CLIENT_SECRET:
        # Useful for local testing. Production should set the secret.
        return True

    if not signature:
        return False

    try:
        parts = dict(
            item.split("=", 1)
            for item in signature.split(",")
            if "=" in item
        )
        timestamp = parts["t"]
        received = parts["s"]
        if abs(time.time() - int(timestamp)) > 300:
            return False

        signed_payload = f"{timestamp}.".encode() + raw_body
        expected = hmac.new(
            TIKTOK_CLIENT_SECRET.encode(),
            signed_payload,
            hashlib.sha256,
        ).hexdigest()
        return hmac.compare_digest(expected, received)
    except (KeyError, ValueError):
        return False


def extract_event(payload: Dict[str, Any]):
    """
    TikTok webhook schemas can vary by product/event.
    This adapter accepts several common field names and is intentionally
    isolated so the exact approved TikTok product payload can be mapped here.
    """
    event_id = (
        payload.get("event_id")
        or payload.get("id")
        or payload.get("request_id")
        or hashlib.sha256(json.dumps(payload, sort_keys=True).encode()).hexdigest()
    )

    event_name = payload.get("event") or payload.get("event_name") or ""

    content = payload.get("content")
    if isinstance(content, str):
        try:
            content = json.loads(content)
        except json.JSONDecodeError:
            pass

    data = content if isinstance(content, dict) else payload

    text = (
        data.get("text")
        or data.get("message")
        or data.get("message_text")
        or data.get("content")
        or ""
    )

    user_id = (
        data.get("user_openid")
        or data.get("user_id")
        or data.get("sender_id")
        or payload.get("user_openid")
        or "unknown-user"
    )

    conversation_id = (
        data.get("conversation_id")
        or data.get("conversation_id")
        or user_id
    )

    return {
        "event_id": str(event_id),
        "event_name": str(event_name),
        "user_id": str(user_id),
        "conversation_id": str(conversation_id),
        "text": str(text).strip(),
        "raw": payload,
    }


def generate_ai_reply(conversation_id: str, user_text: str) -> str:
    if not client:
        raise RuntimeError("OPENAI_API_KEY is not configured")

    messages = [{"role": "developer", "content": AI_SYSTEM_PROMPT}]
    for role, content in history(conversation_id):
        if role in ("user", "assistant"):
            messages.append({"role": role, "content": content})
    messages.append({"role": "user", "content": user_text})

    response = client.responses.create(
        model=OPENAI_MODEL,
        input=messages,
        store=False,
    )
    answer = (response.output_text or "").strip()
    if not answer:
        raise RuntimeError("OpenAI returned an empty response")
    return answer[:4000]


async def send_tiktok_reply(event: Dict[str, Any], reply_text: str) -> Dict[str, Any]:
    """
    Outbound adapter.

    Set TIKTOK_REPLY_URL to the HTTPS endpoint provided by the TikTok product/API
    approved for your app. The exact request schema depends on that product.

    If it is not configured, the generated reply is logged and returned instead
    of pretending that it was sent to TikTok.
    """
    if not TIKTOK_REPLY_URL:
        logger.info("TIKTOK_REPLY_URL is not configured; generated reply: %s", reply_text)
        return {"sent": False, "reason": "TIKTOK_REPLY_URL_NOT_CONFIGURED"}

    payload = {
        "user_id": event["user_id"],
        "conversation_id": event["conversation_id"],
        "text": reply_text,
    }

    headers = {"Content-Type": "application/json"}
    if TIKTOK_REPLY_TOKEN:
        headers["Authorization"] = f"Bearer {TIKTOK_REPLY_TOKEN}"

    async with httpx.AsyncClient(timeout=20) as http:
        response = await http.post(TIKTOK_REPLY_URL, json=payload, headers=headers)

    if response.status_code >= 400:
        logger.error("TikTok reply endpoint returned %s: %s", response.status_code, response.text[:1000])
        raise HTTPException(status_code=502, detail="Reply endpoint rejected the message")

    return {"sent": True, "status_code": response.status_code}


@app.get("/")
async def root():
    return {
        "app": APP_NAME,
        "status": "online",
        "auto_reply": setting("auto_reply", str(AUTO_REPLY_ENABLED).lower()) == "true",
    }


@app.get("/health")
async def health():
    return {"status": "ok"}


@app.post("/admin/auto-reply")
async def admin_auto_reply(enabled: bool):
    set_setting("auto_reply", str(enabled).lower())
    return {"auto_reply": enabled}


@app.post("/webhook/tiktok")
async def tiktok_webhook(
    request: Request,
    tiktok_signature: Optional[str] = Header(default=None, alias="TikTok-Signature"),
):
    raw = await request.body()

    if not verify_tiktok_signature(raw, tiktok_signature):
        raise HTTPException(status_code=401, detail="Invalid TikTok webhook signature")

    try:
        payload = json.loads(raw.decode("utf-8"))
    except json.JSONDecodeError:
        raise HTTPException(status_code=400, detail="Invalid JSON")

    event = extract_event(payload)

    # TikTok webhooks may be delivered more than once.
    if already_processed(event["event_id"]):
        return {"ok": True, "duplicate": True}

    # Ignore events that don't contain a message.
    if not event["text"]:
        return {"ok": True, "ignored": True, "reason": "no_text"}

    enabled = setting("auto_reply", str(AUTO_REPLY_ENABLED).lower()) == "true"
    if not enabled:
        return {"ok": True, "ignored": True, "reason": "auto_reply_disabled"}

    # Save incoming message before generating a response.
    save_message(event["conversation_id"], "user", event["text"])

    # Basic repeated-message/spam protection.
    count = recent_user_message_count(event["conversation_id"])
    if count > SPAM_MAX_MESSAGES:
        reply = "សូមអភ័យទោស 🙏 សូមរង់ចាំបន្តិច ហើយសាកល្បងផ្ញើសារម្ដងទៀត។"
    else:
        try:
            reply = generate_ai_reply(event["conversation_id"], event["text"])
        except Exception as exc:
            logger.exception("AI generation failed: %s", exc)
            return {"ok": True, "error": "ai_generation_failed"}

    save_message(event["conversation_id"], "assistant", reply)
    result = await send_tiktok_reply(event, reply)

    return {"ok": True, "reply": reply, **result}


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host=HOST, port=PORT)
