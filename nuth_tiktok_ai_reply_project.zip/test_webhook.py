import json
import os
import requests

URL = os.getenv("WEBHOOK_URL", "http://127.0.0.1:8000/webhook/tiktok")

payload = {
    "event": "test.message",
    "event_id": "local-test-001",
    "user_openid": "demo-user",
    "content": {
        "text": "Hello, can you help me?"
    }
}

response = requests.post(URL, json=payload, timeout=30)
print(response.status_code)
print(response.text)
